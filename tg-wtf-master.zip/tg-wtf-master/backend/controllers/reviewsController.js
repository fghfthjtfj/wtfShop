

export default class reviewsController {

    static getItemReviews = async (req, res) => {

    }

    static addItemReview = async (req, res) => {

    }

    static deleteItemReview = async (req, res) => {

    }

}