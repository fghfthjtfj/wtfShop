

export default class cartController {

    static getCartItems = async (req, res) => {

    }

    static deleteCartItem = async (req, res) => {

    }

    static addCartItem = async (req, res) => {

    }

    static updateCartItemCount = async (req, res) => {

    }
    

}
