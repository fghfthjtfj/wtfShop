const NoMatch = () => {
    return (
        <><h1>NoMatch</h1></>
    )
}

export default NoMatch;